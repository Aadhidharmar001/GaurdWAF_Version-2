# GuardWAF - Enterprise Agent WAF & Action Guardrail Gateway (PS-5.1)

GuardWAF is a production-ready, context-aware security gateway designed to protect enterprise APIs and databases from unauthorized, rate-limited, out-of-scope, or malicious tool calls initiated by AI Agents.

---

## 🏛️ Enterprise AWS Architecture

```mermaid
graph TD
    subgraph ClientLayer["Client & AI Agent Layer"]
        Agent["AI Agent / LLM Client"]
    end

    subgraph AWSCloud["AWS Cloud (ap-south-1)"]
        subgraph PublicSubnet["VPC Public Subnet"]
            IGW["Internet Gateway / Public IP"]
            
            subgraph FargateService["AWS ECS Fargate Cluster (guardwaf-cluster)"]
                WAF["GuardWAF Container<br/>(FastAPI on Port 8000)<br/>guardwaf-service"]
            end
        end

        subgraph PrivateSubnet["VPC DB Security Group"]
            RDS[("Amazon RDS PostgreSQL<br/>(guardwaf-db:5432)")]
        end

        subgraph SecuritySecrets["Security & Governance"]
            SM["AWS Secrets Manager<br/>(guardwaf/db_url & openai_key)"]
            CW["Amazon CloudWatch<br/>(/ecs/guardwaf)"]
        end
    end

    Agent -->|"HTTP /proxy/tool"| IGW
    IGW --> WAF
    WAF -->|"SQLAlchemy ORM<br/>Audit Logs & HITL Queue"| RDS
    SM -.->|"Retrieve Credentials"| WAF
    WAF -.->|"App & Audit Logs"| CW
```

---

## 📊 Deployment Summary

| Infrastructure Component | AWS Service | Purpose & Details |
| :--- | :--- | :--- |
| **Docker** | Containerization | Packages GuardWAF FastAPI application and dependencies |
| **Amazon ECR** | Container Registry | Stores production Docker images (`161012475437.dkr.ecr.ap-south-1.amazonaws.com/guardwaf:latest`) |
| **Amazon ECS Fargate** | Serverless Compute | Executes the GuardWAF container with zero server management |
| **Amazon RDS PostgreSQL** | Managed Database | Persists audit logs, HITL approval queue, and stateful sequence data |
| **Amazon CloudWatch** | Observability | Ingests and aggregates structured application logs (`/ecs/guardwaf`) |
| **AWS Secrets Manager** | Key Management | Securely injects `DATABASE_URL` and `OPENAI_API_KEY` at task startup |

---

## 🤖 LLM Provider Integration (xAI Grok)

GuardWAF natively supports **xAI Grok** as its primary LLM reasoning provider while maintaining zero code friction for evaluators:
*   **OpenAI SDK Compatibility**: xAI Grok exposes an OpenAI-compatible API (`https://api.x.ai/v1`), allowing the standard `openai` Python package to interface directly with Grok models (`grok-beta`, `grok-2`).
*   **Zero Infrastructure Changes**: The environment variable remains `OPENAI_API_KEY` to avoid breaking existing AWS Secrets Manager, ECS Task Definitions, or local `.env` setups.
*   **Seamless Model Switching**: To switch back to native OpenAI models, simply set `OPENAI_BASE_URL=https://api.openai.com/v1` and supply an OpenAI API key—no application code changes required.

---

## 🚀 Live Demo & Local Development

### 🌐 Live AWS ECS Fargate Deployment
GuardWAF is containerized and deployed on **AWS ECS Fargate** backed by **Amazon RDS PostgreSQL** in region `ap-south-1`.

*   **Live Dashboard UI:** `http://<fargate-public-ip>:8000/static/index.html`
*   **Health Check Endpoint:** `http://<fargate-public-ip>:8000/health`
*   **FastAPI Interactive Docs:** `http://<fargate-public-ip>:8000/docs`

> *Note for Evaluators: To deploy or query the live Fargate instance, follow the step-by-step instructions in [infra/deploy.md](file:///e:/AI_projects/aivar_project/infra/deploy.md).*

### 💻 Local Development Options

#### Option A: Native Python (SQLite Default)
```bash
# Install dependencies
pip install -r requirements.txt

# Run GuardWAF (defaults to local SQLite database waf_governance.db)
uvicorn app.main:app --reload --port 8000
```

#### Option B: Docker Compose (Local PostgreSQL)
```bash
# Start FastAPI application + PostgreSQL 15 containers locally
docker-compose up --build
```

Access points:
*   Local Dashboard UI: `http://localhost:8000/static/index.html`
*   Local Health Check: `http://localhost:8000/health`

---

## 🔍 The Problem We Are Solving (PS-5.1)

AI agents are given **Tools** (APIs) to automatically perform actions like querying databases, executing SQL code, or sending emails. Traditional security models fail to govern them because:
*   **Text Guardrails are Insufficient:** An agent can generate polite, non-toxic text that triggers a tool call to delete 10,000 database records.
*   **Session Data Scopes:** Agents operating with delegated user credentials can inadvertently access data belonging to another customer (`customer_id` scope breach).
*   **Sequence Violations:** Agents can skip critical verification steps (e.g. calling `send_email` without prior `verify_recipient` check).
*   **Runaway Loops:** Logic loops in agents can lead to hundreds of unauthorized API calls per minute.

### How GuardWAF Solves This
GuardWAF acts as a **transparent reverse-proxy** between the agent and target tools. Every tool request goes through `/proxy/tool` where the WAF checks rate limits, stateful tool sequences, parameter blocklists, and session data scopes. High-risk operations are automatically held in the **Human-in-the-Loop Queue** for manual administrator approval.

---

## 🏗️ Codebase Architecture

```
aivar_project/
├── app/                        # Modular Core Application
│   ├── main.py                 # FastAPI app entrypoint & route registration
│   ├── config.py               # Environment settings & DB URL normalization
│   ├── models.py               # Pydantic schemas (SessionContext, ToolCallRequest, etc.)
│   ├── db/
│   │   ├── database.py         # Dynamic SQLAlchemy engine (PostgreSQL / SQLite fallback)
│   │   └── orm_models.py       # AuditLog, HitlQueue, SequenceState ORM tables
│   ├── proxy/
│   │   ├── interceptor.py      # Master pre-execution evaluator
│   │   ├── rate_limiter.py     # Sliding-window rate limit checker
│   │   ├── param_validator.py  # Blocklist regex & size limits
│   │   ├── data_scope.py       # SessionContext-aware data scope checker (customer_id)
│   │   ├── sequence_guard.py   # Stateful sequence checker
│   │   └── shadow_mode.py      # Log-only evaluation path for flagged rules
│   ├── hitl/
│   │   ├── queue_manager.py    # HITL queue management
│   │   └── routes.py           # FastAPI routes for HITL actions
│   ├── audit/
│   │   └── logger.py           # Structured database audit logger
│   ├── llm/
│   │   └── agent_client.py     # OpenAI LLM integration wrapper
│   ├── health/
│   │   └── routes.py           # GET /health DB check, uptime & engine status
│   └── rules_engine/
│       ├── loader.py           # Parses rules.yaml into typed rules
│       └── evaluator.py        # Rule evaluator coordinator
├── rules.yaml                  # Declarative policy definition
├── static/
│   └── index.html              # Dashboard UI (Live traffic, HITL queue, rule editor)
├── simulation.py               # Multi-scenario compliance test suite
├── tests/
│   └── test_rules_engine.py    # Unit test suite (100% Pass)
├── Dockerfile                  # Container definition for GuardWAF
├── docker-compose.yml          # PostgreSQL 15 + FastAPI container orchestration for local dev
├── infra/
│   ├── ecs-task-def.json       # Production AWS ECS Fargate Task Definition (Single Container)
│   ├── architecture.mermaid    # Visual Mermaid architecture diagram
│   ├── deployment_checklist.md # DevSecOps readiness checklist
│   └── deploy.md               # Step-by-step AWS deployment runbook
├── requirements.txt
└── README.md
```

---

## 🧪 Unit Testing & Specification Verification

To run the full specification verification unit test suite:
```bash
python -m pytest
```
All 13 tests mirror the PS-5.1 success criteria 1:1 and pass with 100% compliance.

To run the simulation harness:
```bash
python simulation.py
```
